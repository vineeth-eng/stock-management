enum screenType { LCD, LED, OTHER };

public class Screen {
	
	// the Screen class attributes / field
	private int sizeInCM;
	private double price;
	private int referenceNumber;
	private screenType currrentscreenType;
	//public enum screenType { LCD, LED, OTHER };
	
	// constructor
	 public Screen(int size, double price, screenType screenType, int referenceNumber ) {
		this.sizeInCM = size;
		this.price = price;
		this.currrentscreenType = screenType;
		this.referenceNumber = referenceNumber; 
	}
	 
	// the Screen class methods
    public int getSize() {
        return this.sizeInCM;
    }   
    public double getPrice() {
        return this.price;
    }
    public screenType getScreenType() {
        return this.currrentscreenType;
    }  
    public int getRefNumber() {
        return this.referenceNumber;
    } 

    public void setSize(int size) {
    	this.sizeInCM = size;
    }
    public void setPrice(double price) {
    	this.price = price;
    }
    public void setType(screenType type) {
    	this.currrentscreenType = type;
    }
    public void setRefNumber(int referenceNum) {
    	this.referenceNumber = referenceNum;
    }
}
