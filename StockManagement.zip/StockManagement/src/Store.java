public class Store {

	// the Store class attributes / field
	private String address;
	private int numberOfScreen;
	private int numberOfHarddisk;
	Screen [] screen;
	HardDisk [] harddisk;
	
	// constructor
	 public Store(String addr, int numScreen, int numofHD, Screen [] screen, HardDisk [] hd ) {
		this.address = addr;
		this.numberOfScreen = numScreen;
		this.numberOfHarddisk = numofHD;
		this.screen = screen;
		this.harddisk = hd;
	}
	    
	// the Store class Get methods
	public String getStoreAddress() {
	    return this.address;
	}   
	public int getnumberOfScreen() {
	    return this.numberOfScreen;
	}
	public int getnumberOfHarddisk() {
	    return this.numberOfHarddisk;
	}  
	
	// the Store class Set methods
	public void setAddress(String addr) {
		this.address = addr;
	}
	public void setnumberOfScreen(int number) {
	    this.numberOfScreen = number;
	}
	public void setnumberOfHarddisk(int totalNumber) {
	     this.numberOfHarddisk = totalNumber;
	}  
}
