//*******************************************************************
//  HardDisk
//
// used for exporting HardDisk properties
//*******************************************************************
enum harddiskType { internal, external };

public class HardDisk {

	// the HardDisk class attributes / field
	private int sizeInGB;
	private double price;
	private harddiskType currentDiskType;
	private int referenceNumber;
	
	// constructor
	 public HardDisk(int size, double price, harddiskType hdType ) {
		this.sizeInGB = size;
		this.price = price;
		this.currentDiskType = hdType;
	}
	 
	// the HardDisk class Get methods
    public int getSize() {
        return this.sizeInGB;
    }   
    public double getPrice() {
        return this.price;
    }
    public harddiskType getScreenType() {
        return this.currentDiskType;
    } 
    public int getRefNumber() {
        return this.referenceNumber;
    } 
    
	// the HardDisk class Set methods
    public void setSize(int size) {
    	this.sizeInGB = size;
    }
    public void setPrice(double price) {
    	this.price = price;
    }
    public void setType(harddiskType type) {
    	this.currentDiskType = type;
    }
    public void setRefNumber(int num) {
    	this.referenceNumber = num;
    }
    
}
