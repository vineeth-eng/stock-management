import java.util.Random;

public class Test {
	
	private int index;
	private static void enterScreens()
	{
		Random r = new Random();
		short shrtInteger = (short) r.nextInt(1 << 15);
		double ramdomDouble =  r.nextDouble();
		int ramdomInteger =  r.nextInt();
		Screen [] screensLCD = new Screen[40];
		Screen [] screensLED = new Screen[40];
		Screen [] screensOther = new Screen[40];
		
		screenType screenType = screenType.LCD;
		for(int i=0; i<40; i++)
		{
			screensLCD[i].setSize(shrtInteger);
			screensLCD[i].setPrice(ramdomDouble);
			screensLCD[i].setRefNumber(ramdomInteger);
			screensLCD[i].setType(screenType);
			index++;
			store1.setnumberOfScreen(index);
		}
		screenType = screenType.LED;
		for(int i=0; i<30; i++)
		{
			screensLED[i].setSize(shrtInteger);
			screensLED[i].setPrice(ramdomDouble);
			screensLED[i].setRefNumber(ramdomInteger);
			screensLED[i].setType(screenType);
		}
		screenType = screenType.OTHER;
		for(int i=0; i<30; i++)
		{
			screensOther[i].setSize(shrtInteger);
			screensOther[i].setPrice(ramdomDouble);
			screensOther[i].setRefNumber(ramdomInteger);
			screensOther[i].setType(screenType);
		}
	}
	private static void enterHardDisk()
	{
		Random r = new Random();
		short shrtInteger = (short) r.nextInt(1 << 15);
		double ramdomDouble =  r.nextDouble();
		int ramdomInteger =  r.nextInt();
		
		HardDisk [] hardDiskInternal = new HardDisk[40];
		HardDisk [] hardDiskExternal = new HardDisk[40];
		
		harddiskType hdType = harddiskType.internal;
		for(int i=0; i<40; i++)
		{
			hardDiskInternal[i].setSize(shrtInteger);
			hardDiskInternal[i].setPrice(ramdomDouble);
			hardDiskInternal[i].setRefNumber(ramdomInteger);
			hardDiskInternal[i].setType(hdType);
		}
		hdType = harddiskType.external;
		for(int i=0; i<40; i++)
		{
			hardDiskExternal[i].setSize(shrtInteger);
			hardDiskExternal[i].setPrice(ramdomDouble);
			hardDiskExternal[i].setRefNumber(ramdomInteger);
			hardDiskExternal[i].setType(hdType);
		}
	}
	public static void main(String[] args)
	{
		enterScreens();
		enterHardDisk();
		String storeAddr = "123 Main Road, IInd Store, France";
		Store store1 = new Store(storeAddr, "2nd street Paris", 5, arrayEmployee);
		
		System.out.println("bank Name is     : " + bnp.getBank()); 
		System.out.println("bank balance    : " +  bnp.getBalance());
		
		System.out.println("--------------------------------------------------------- ");

		System.out.println("Company Name is     : " + company1.getName()); 
		System.out.println("Company Addreess    : " + company1.getAdress());
		System.out.println("No of Employees     : " + company1.getNumberOfemployees());
	
		System.out.println("--------------------------------------------------------- ");
		
		System.out.println("Employee 1 Name is : " + company1.employees[0].getEmployeeName()); 
		System.out.println("Employee 1 Name is : " + company1.employees[0].getEmployeeAge()); 
		System.out.println("bank Name is       : " + company1.employees[0].account.getBank()); 
		System.out.println("bank balance       : " + company1.employees[0].account.getBalance());
		System.out.println("--------------------------------------------------------- ");
		System.out.println("Employee 2 Name is : " + company1.employees[1].getEmployeeName()); 
		System.out.println("Employee 2 Name is : " + company1.employees[1].getEmployeeAge()); 
		System.out.println("bank Name is       : " + company1.employees[1].account.getBank()); 
		System.out.println("bank balance       : " + company1.employees[1].account.getBalance());
		System.out.println("--------------------------------------------------------- ");
		System.out.println("Employee 3 Name is : " + company1.employees[2].getEmployeeName()); 
		System.out.println("Employee 3 Name is : " + company1.employees[2].getEmployeeAge()); 
		System.out.println("bank Name is       : " + company1.employees[2].account.getBank()); 
		System.out.println("bank balance       : " + company1.employees[2].account.getBalance());
		System.out.println("--------------------------------------------------------- ");
		System.out.println("Employee 4 Name is : " + company1.employees[3].getEmployeeName()); 
		System.out.println("Employee 4 Name is : " + company1.employees[3].getEmployeeAge()); 
		System.out.println("bank Name is       : " + company1.employees[3].account.getBank()); 
		System.out.println("bank balance       : " + company1.employees[3].account.getBalance());
		System.out.println("--------------------------------------------------------- ");
		System.out.println("Employee 5 Name is : " + company1.employees[4].getEmployeeName()); 
		System.out.println("Employee 5 Name is : " + company1.employees[4].getEmployeeAge()); 
		System.out.println("bank Name is       : " + company1.employees[4].account.getBank()); 
		System.out.println("bank balance       : " + company1.employees[4].account.getBalance());
		System.out.println("--------------------------------------------------------- ");
		
	}
}
